package com.springbootexample.FactorialExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FactorialExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FactorialExampleApplication.class, args);
	}

}
