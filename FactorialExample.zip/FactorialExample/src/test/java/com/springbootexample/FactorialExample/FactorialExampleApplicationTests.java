package com.springbootexample.FactorialExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactorialExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
